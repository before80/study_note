# nvm教程

## nvm 的安装

### Linux 上安装nvm



### Window 上安装nvm



## 常用nvm命令

#### nvm arch [32|64]

显示node是运行在32位还是64位模式, 

或者 指定32或64来覆盖默认体系结构。

![1566536308988](D:\自制教程\nvm\nvm教程.assets\1566536308988.png)

![1566536430389](D:\自制教程\nvm\nvm教程.assets\1566536430389.png)

nvm install []

http://www.hehaibao.com/download-and-use-nvm-window/

