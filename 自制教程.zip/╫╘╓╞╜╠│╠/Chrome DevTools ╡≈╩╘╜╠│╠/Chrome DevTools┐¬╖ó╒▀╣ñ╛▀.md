



## Chrome DevTools开发者工具**

### 1.2 Chrome DevTools功能简介(9大功能面板)

1. Elements元素面板

   检查和调整页面, 调试DOM, 调试CSS

2. Network网络面板

   调试请求, 了解页面静态资源分布, 网页性能检查

3. Console控制台面板

   调试JavaScript、查看Console log 日志、交互式代码调试

4. Sources源代码资源面板

   调试JavaScript页面源代码, 进行断点调试代码

5. Application 应用面板

   查看&调试客户端存储, 如Cookie, LocalStorage, SessionStorage等

6. Performance性能面板

   查看页面性能细节, 细粒度对网页载入进行性能优化( 高阶 )

7. Memory内存面板

   JavaScript CPU 分析器, 内存堆分析器 ( 高阶 )

8. Security安全面板

   查看页面安全及证书问题

9. Audits面板

   使用Google Lighthouse 辅助性能分析, 给出优化建议 ( 高阶 )

### **1.3 打开开发者工具**

#### **打开方式:**

- 在Chrome菜单中选择: 更多工具-->开发者工具
- 在页面元素上右键点击, 选择 "检查"
- 快捷键 ( 多种 ), 推荐使用快捷键进行打开

#### **使用快捷键打开方式:**

1. 打开最近关闭的状态: 

   Ctrl + Shift + I (Windows) 或者 Cmd + Opt + I (Mac)

2. 快速查看DOM或样式: 

   Ctrl + Shift + C(Windows) 或者 Cmd + Opt + C (Mac)

3. 快速进入Console 查看log运行JavaScript: 

   Ctrl + Shift + J (Windows) 或者 Cmd + Opt + J (Mac)

4. F12 打开



